# NGF Mk7 hybrid sensor overlay

Files:
- `src/prometheus_ngf/sensor.py`: opt-in Scapy packet metadata capture, bounded flow summaries, optional short PCAP, and Suricata EVE tailing.
- `api_endpoints_snippet.py.txt`: API endpoints to merge into the existing `api.py`; see comments for the lazy sensor property required in `service.py`.

Safety and limitations:
- Capture is not started automatically; select an authorized interface explicitly.
- API should stay bound to 127.0.0.1 and all new endpoints must call the existing `auth()`.
- Metadata is retained in memory only. PCAP is off by default and should be limited to 1–600 seconds.
- Sensor is alpha code, not full DPI, TCP reassembly, or production NDR. Validate with tests before use.
- Scapy packet capture may require CAP_NET_RAW. Prefer a narrow systemd capability over running the API as root.
- Suricata EVE reader tails new lines only; the service user must have read permission on the EVE file.
- Keep response mode dry-run and do not enable blocking.

Suggested install:
1. `sudo systemctl stop prometheus-ngf-mk7.service`
2. Back up project source: `cp -a src/prometheus_ngf "backups/src-prometheus_ngf-$(date +%Y%m%d-%H%M%S)"`
3. Copy `src/prometheus_ngf/sensor.py` into the same package directory.
4. Install Scapy in venv: `.venv/bin/python -m pip install scapy`
5. Integrate `api_endpoints_snippet.py.txt` and the lazy property into your source; don't paste the whole snippet into the shell.
6. `source .venv/bin/activate && python -m compileall -q src/prometheus_ngf && python -m pytest -q`
7. Restart service, review logs, then test `/v1/sensor/interfaces` and `/v1/sensor/status` with the existing bearer token.
8. Only if capture returns permission errors, review the unit and consider `AmbientCapabilities=CAP_NET_RAW` and `CapabilityBoundingSet=CAP_NET_RAW`; don't run the whole API as root.

Rollback: stop service, restore the source backup, remove sensor.py if newly added, then restart service. Existing database is not changed by installing these files.
