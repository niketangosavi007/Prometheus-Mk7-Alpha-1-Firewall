"""Opt-in Scapy packet metadata capture and Suricata EVE tailer."""
import json, os, threading, time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

class HybridSensor:
    def __init__(self, service):
        self.service=service; self.lock=threading.RLock(); self.stop_event=threading.Event()
        self.thread=None; self.eve_thread=None; self.interface=None; self.eve_path=None
        self.pcap_path=None; self.packets=0; self.bytes=0; self.protocols=Counter()
        self.last_packet=None; self.started=None; self.flows={}; self.errors=[]; self.eve_records=0
    def interfaces(self):
        try:
            from scapy.all import get_if_list
            return sorted(get_if_list())
        except Exception: return []
    def status(self):
        with self.lock:
            return {"running":bool(self.thread and self.thread.is_alive() and not self.stop_event.is_set()),
              "interface":self.interface,"started_at":self.started,"last_packet_at":self.last_packet,
              "packets_seen":self.packets,"bytes_seen":self.bytes,"protocols":dict(self.protocols),
              "active_flow_count":len(self.flows),"top_flows":sorted(self.flows.values(),key=lambda x:x["last_seen"],reverse=True)[:20],
              "suricata_eve_path":self.eve_path,"suricata_records":self.eve_records,"pcap_path":self.pcap_path,
              "errors":self.errors[-5:],"response_mode":"dry-run","enforcement_enabled":False}
    def start(self, interface, eve_path=None, pcap_path=None, pcap_seconds=60):
        from scapy.all import get_if_list
        if interface not in get_if_list(): raise ValueError("Interface not found.")
        if eve_path and not Path(eve_path).is_file(): raise ValueError("Suricata EVE file not found.")
        if pcap_path:
            if not 1 <= int(pcap_seconds) <= 600: raise ValueError("PCAP duration must be 1–600 seconds.")
            allowed=Path(os.getenv("NGF_PCAP_DIR","./data/pcap")).resolve()
            p=Path(pcap_path).resolve()
            if allowed not in p.parents: raise ValueError("PCAP must be inside NGF_PCAP_DIR.")
            allowed.mkdir(parents=True,exist_ok=True); self.pcap_path=str(p)
        with self.lock:
            if self.thread and self.thread.is_alive(): raise RuntimeError("Sensor is already running.")
            self.stop_event.clear(); self.interface=interface; self.eve_path=eve_path
            self.started=datetime.now(timezone.utc).isoformat(); self.errors=[]
            self.thread=threading.Thread(target=self._capture,args=(pcap_seconds if pcap_path else 0,),daemon=True)
            self.thread.start()
            if eve_path:
                self.eve_thread=threading.Thread(target=self._tail_eve,daemon=True); self.eve_thread.start()
        return self.status()
    def stop(self):
        self.stop_event.set()
        if self.thread: self.thread.join(timeout=3)
        if self.eve_thread: self.eve_thread.join(timeout=2)
        return self.status()
    def _capture(self, pcap_seconds):
        try:
            from scapy.all import sniff, PcapWriter
            from scapy.layers.inet import IP, TCP, UDP, ICMP
            from scapy.layers.inet6 import IPv6
            writer=PcapWriter(self.pcap_path,append=False,sync=True) if self.pcap_path else None
            deadline=time.monotonic()+pcap_seconds if writer else 0
            def on_packet(pkt):
                if self.stop_event.is_set(): return
                now=datetime.now(timezone.utc).isoformat(); src=dst="OTHER"; proto="OTHER"; sport=dport=None
                if IP in pkt: src,dst=pkt[IP].src,pkt[IP].dst
                elif IPv6 in pkt: src,dst=pkt[IPv6].src,pkt[IPv6].dst
                if TCP in pkt: proto="TCP"; sport,dport=int(pkt[TCP].sport),int(pkt[TCP].dport)
                elif UDP in pkt: proto="UDP"; sport,dport=int(pkt[UDP].sport),int(pkt[UDP].dport)
                elif ICMP in pkt: proto="ICMP"
                elif IPv6 in pkt: proto="IPv6"
                elif IP in pkt: proto="IP"
                key=f"{src}:{sport}->{dst}:{dport}/{proto}"; n=len(pkt)
                with self.lock:
                    self.packets+=1; self.bytes+=n; self.protocols[proto]+=1; self.last_packet=now
                    f=self.flows.setdefault(key,{"flow":key,"source_ip":src,"destination_ip":dst,"source_port":sport,"destination_port":dport,"protocol":proto,"packets":0,"bytes":0,"first_seen":now})
                    f["packets"]+=1; f["bytes"]+=n; f["last_seen"]=now
                    if len(self.flows)>1000: self.flows.pop(next(iter(self.flows)))
                if writer and time.monotonic() <= deadline: writer.write(pkt)
                elif writer:
                    writer.close()
                    with self.lock: self.pcap_path=None
            sniff(iface=self.interface,prn=on_packet,store=False,stop_filter=lambda _:self.stop_event.is_set())
            if writer: writer.close()
        except Exception as e:
            with self.lock: self.errors.append("Capture: "+str(e))
            self.stop_event.set()
    def _tail_eve(self):
        try:
            with open(self.eve_path,"r",encoding="utf-8",errors="replace") as f:
                f.seek(0,os.SEEK_END)
                while not self.stop_event.is_set():
                    line=f.readline()
                    if not line: time.sleep(.25); continue
                    try:
                        from .ingest import parse_eve_record
                        ev=parse_eve_record(json.loads(line))
                        if ev: self.service.process(ev); self.eve_records+=1
                    except Exception as e:
                        with self.lock: self.errors.append("EVE: "+str(e))
        except Exception as e:
            with self.lock: self.errors.append("EVE reader: "+str(e))
