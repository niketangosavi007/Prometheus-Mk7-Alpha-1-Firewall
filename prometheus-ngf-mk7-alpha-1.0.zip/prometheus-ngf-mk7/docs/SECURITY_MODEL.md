# Security model and deployment boundary

## Release status
Alpha 1.0 is a production-oriented alpha, not a certified production firewall. It is a detection/policy service with dry-run decisions. The included nftables file is an example and is never applied by the application.

## Trust boundaries
- Sensors and imported EVE JSON are untrusted input. Validate and bound them.
- The API requires `NGF_API_TOKEN` for ingest, findings, stats, and metrics. Without it, protected endpoints return 503. Keep the service bound to loopback unless a separately secured reverse proxy is configured.
- The detector has no root privileges and cannot execute arbitrary shell commands.
- Response decisions are advisory; `executed` remains false in this release.
- nftables changes must be reviewed, syntax-checked, and applied by an administrator with out-of-band recovery access.

## Operational requirements before production
1. Define inbound/outbound/forward policy for the actual topology; the example set is not a complete default-deny firewall.
2. Validate on a dedicated VM or console-accessible host with snapshots and rollback.
3. Run performance, soak, restart, malformed-input, privilege-boundary, and adversarial tests.
4. Review authentication, secret rotation, TLS/reverse-proxy design, database permissions, log retention, backup/restore, and patch process.
5. Calibrate detector thresholds against representative labeled traffic; alert score is not probability.
6. Do not enable autonomous blocking until a separately reviewed response worker, action rate limits, expiring sets, allowlists, audit integrity, and rollback tests exist.
