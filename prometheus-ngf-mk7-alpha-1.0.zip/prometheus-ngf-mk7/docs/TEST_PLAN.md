# Test plan

## Unit tests
- Validate event fields and IP addresses.
- Check severity/risk mapping and transparent evidence.
- Verify policy decisions never claim a real action executed.
- Verify SQLite event/finding/decision persistence.
- Verify malformed EVE rows are skipped rather than terminating ingestion.

## Lab integration tests
- Use a VM or isolated virtual network; do not test firewall enforcement on the primary host first.
- Replay known benign and labeled test events.
- Measure precision, recall, false positives, event throughput, and p95 processing latency.
- Test API token rejection and bind the service to loopback by default.
- Simulate database unavailable, malformed records, service restarts, and duplicate events.

## Release gates
- All automated tests pass.
- No unexpected host firewall changes.
- Every response decision is persisted with a reason.
- Detection metrics are documented on a held-out dataset.
- Automated blocking remains disabled until explicit safety review.


## Alpha 1 release gates
- [ ] Protected API routes fail closed when no token is configured.
- [ ] Protected API routes reject missing/incorrect bearer tokens.
- [ ] Source addresses in configured protected networks cannot be containment candidates.
- [ ] All response decisions remain non-executing in Alpha 1.
- [ ] nftables template is syntax-checked on the target distribution before manual application.
- [ ] Replay tests and performance/soak tests completed with representative data.
- [ ] Backup/restore and incident recovery rehearsed.
