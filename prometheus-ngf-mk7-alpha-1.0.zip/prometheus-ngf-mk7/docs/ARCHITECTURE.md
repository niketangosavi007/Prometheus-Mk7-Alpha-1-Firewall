# NGF Mk7 Alpha 0.1 Architecture

## Data path
1. Suricata EVE JSON or a validated API event enters the ingestion boundary.
2. Pydantic validates addresses, ports, timestamps, and non-negative numeric fields.
3. The event is stored in SQLite.
4. A transparent baseline detector adds evidence and computes a 0–100 risk score.
5. The deterministic policy engine returns record, alert, or would-block.
6. Findings, decisions, and audit details are stored for review.

## Trust boundaries
- The detector is unprivileged and cannot change firewall state.
- The policy engine is deterministic; model output is never executable input.
- Alpha 0.1 has no real firewall modification path. `would_block` is a simulation only.
- API access can be protected with `NGF_API_TOKEN`; bind to 127.0.0.1 unless network exposure is explicitly secured.

## Planned extensions
- Flow aggregation with time-window state persisted across restarts.
- Optional Isolation Forest model with dataset/version tracking and calibration.
- Dedicated nftables response worker with a narrow command interface, expiring set entries, allowlist enforcement, rollback, and separate privileges.
- Suricata inline IPS only after dedicated lab validation.
- eBPF/XDP only after profiling identifies a performance need.
- PQC through maintained, standards-conformant libraries and protocols.
