# Operations guide

## Install (Kali/Debian)
```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip nftables suricata
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
pip install -e '.[test,ml]'
pytest -q
ngf demo
```

## Run local API
```bash
export NGF_API_TOKEN="$(python -c 'import secrets; print(secrets.token_urlsafe(32))')"
ngf serve --host 127.0.0.1 --port 8787
```
Use the token in the same shell for curl. Do not expose this API directly to the internet.

## Suricata ingestion
Point `ngf ingest-eve` at a copied EVE JSON file. For continuous ingestion, use a supervised log shipper or a dedicated bounded tailer; do not use an unbounded shell loop as a production daemon.

## nftables example
Review `config/ngf-nftables.example.nft` and customize for the host. Syntax-check only: `ngf check-nftables config/ngf-nftables.example.nft`. This command does not apply rules. Applying even valid rules can interrupt networking; use console access, a maintenance window, and a tested rollback plan.
