Runtime database and event files are created here. Keep generated data out of version control.
