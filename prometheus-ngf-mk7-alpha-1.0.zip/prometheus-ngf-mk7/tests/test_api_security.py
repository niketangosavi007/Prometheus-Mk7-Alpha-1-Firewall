from fastapi.testclient import TestClient
from prometheus_ngf import api

def test_protected_endpoints_fail_closed_without_token(monkeypatch):
    monkeypatch.setattr(api, "API_TOKEN", "")
    c = TestClient(api.app)
    assert c.get("/v1/stats").status_code == 503
    assert c.get("/metrics").status_code == 503

def test_health_is_available_without_token():
    c = TestClient(api.app)
    assert c.get("/health").status_code == 200
