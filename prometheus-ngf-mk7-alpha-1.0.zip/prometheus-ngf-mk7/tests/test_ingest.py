from prometheus_ngf.ingest import parse_eve_record

def test_parse_suricata_alert():
    event = parse_eve_record({"timestamp":"2026-10-20T10:00:00Z", "event_type":"alert", "src_ip":"192.0.2.1", "src_port":1234, "dest_ip":"198.51.100.1", "dest_port":443, "proto":"TCP", "alert":{"severity":2,"signature":"Example alert"}})
    assert event is not None
    assert event.source_ip == "192.0.2.1"
    assert event.signature == "Example alert"

def test_unsupported_event_ignored():
    assert parse_eve_record({"event_type":"fileinfo"}) is None
