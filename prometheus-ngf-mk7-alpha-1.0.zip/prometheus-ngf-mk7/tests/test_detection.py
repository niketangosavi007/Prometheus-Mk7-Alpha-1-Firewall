from prometheus_ngf.models import NetworkEvent
from prometheus_ngf.detection import DetectionEngine
from prometheus_ngf.policy import PolicyEngine

def test_high_severity_alert_is_candidate_but_not_executed():
    event = NetworkEvent(event_id="e1", source_ip="192.0.2.10", destination_ip="198.51.100.20", destination_port=443, event_type="alert", severity="critical", signature="critical test alert")
    finding = DetectionEngine().analyze(event)
    decision = PolicyEngine().decide(finding)
    assert finding.risk_score >= 75
    assert decision.decision == "would_block"
    assert decision.executed is False

def test_normal_event_is_recorded():
    event = NetworkEvent(event_id="e2", source_ip="192.0.2.11", destination_ip="198.51.100.21", destination_port=443)
    finding = DetectionEngine().analyze(event)
    decision = PolicyEngine().decide(finding)
    assert decision.decision == "record"
    assert not decision.executed

def test_invalid_ip_rejected():
    import pytest
    with pytest.raises(ValueError):
        NetworkEvent(source_ip="not-an-ip")
