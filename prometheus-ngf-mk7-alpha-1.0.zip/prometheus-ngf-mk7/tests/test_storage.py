from prometheus_ngf.models import NetworkEvent
from prometheus_ngf.service import NGFService

def test_service_persists_event_and_finding(tmp_path):
    service = NGFService(str(tmp_path / "test.db"))
    result = service.process(NetworkEvent(event_id="test-1", source_ip="192.0.2.1", destination_ip="198.51.100.1", destination_port=80))
    assert result["event"]["event_id"] == "test-1"
    assert service.store.stats()["events"] == 1
    assert service.store.stats()["findings"] == 1
    assert service.store.stats()["decisions"] == 1
