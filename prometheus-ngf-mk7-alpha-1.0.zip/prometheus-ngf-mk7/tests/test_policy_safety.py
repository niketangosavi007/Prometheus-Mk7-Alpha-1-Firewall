from prometheus_ngf.models import DetectionFinding
from prometheus_ngf.policy import PolicyEngine

def finding(score=90):
    return DetectionFinding(finding_id="f1", event_id="e1", risk_score=score, severity="high", evidence=["test"], recommended_action="containment_candidate")

def test_loopback_is_protected():
    d = PolicyEngine().decide(finding(), "127.0.0.1")
    assert d.decision == "blocked_by_policy" and d.executed is False

def test_high_risk_is_still_dry_run():
    d = PolicyEngine().decide(finding(), "203.0.113.8")
    assert d.decision == "would_block" and d.executed is False and d.ttl_seconds == 300

def test_ttl_is_bounded():
    assert PolicyEngine(block_ttl_seconds=999999).block_ttl_seconds == 3600
    assert PolicyEngine(block_ttl_seconds=1).block_ttl_seconds == 30
