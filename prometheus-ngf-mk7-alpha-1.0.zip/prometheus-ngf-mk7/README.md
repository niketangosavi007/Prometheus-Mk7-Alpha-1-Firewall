# Prometheus NGF Mk7 — Alpha 1.0

**Release:** `1.0.0-alpha.1` · **Target:** Kali Linux / Debian · **Status:** production-oriented alpha, not production-certified.

Prometheus NGF Mk7 consolidates the Mk1–Mk6 direction into a modular Linux network security platform: network telemetry, explainable detection, deterministic response policy, audit storage, API and metrics. This release intentionally does **not** apply firewall rules or execute automatic blocking.

## Included
- Network event schema and Suricata EVE JSON ingestion
- Explainable rule/baseline detection and risk scoring
- Deterministic policy gate with protected-network checks and bounded TTL
- SQLite event/finding/decision/audit storage
- FastAPI API with fail-closed token requirement for protected routes
- Prometheus metrics endpoint (token-protected)
- nftables example in a dedicated table; validation command only, no apply command
- systemd hardening example, operations/security docs, automated tests

## Install and test
```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip nftables suricata
python3 -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
pip install -e '.[test,ml]'
pytest -q
ngf demo
```

## Start local API
```bash
export NGF_API_TOKEN="$(python -c 'import secrets; print(secrets.token_urlsafe(32))')"
ngf serve --host 127.0.0.1 --port 8787
```
The API listens on loopback by default. Protected endpoints return 503 if `NGF_API_TOKEN` is not configured. Keep secrets out of source control.

## Validate an nftables example (does not apply it)
```bash
ngf check-nftables config/ngf-nftables.example.nft
```
Review and adapt the example before any manual use. Do not load firewall rules over a remote session without out-of-band recovery access.

## Architecture and release notes
- [Architecture](docs/ARCHITECTURE.md)
- [Security model](docs/SECURITY_MODEL.md)
- [Operations guide](docs/OPERATIONS.md)
- [Test plan](docs/TEST_PLAN.md)

## Important limitations
The detector is a heuristic baseline, not a validated trained AI model. This release has no real automatic containment, no XDP/eBPF dataplane, no HA cluster, and no post-quantum protocol integration. Those are follow-on milestones requiring dedicated testing. A passing test suite does not certify a firewall for production.
