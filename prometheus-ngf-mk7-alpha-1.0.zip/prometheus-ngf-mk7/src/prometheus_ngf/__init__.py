"""Prometheus NGF Mk7 Alpha 0.1."""
__version__ = "0.1.0"
