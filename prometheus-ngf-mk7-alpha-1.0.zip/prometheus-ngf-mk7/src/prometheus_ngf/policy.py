from ipaddress import ip_address, ip_network
from .models import DetectionFinding, ResponseDecision

class PolicyEngine:
    """Fail-safe policy gate. This release only produces dry-run decisions."""
    def __init__(self, medium_threshold=45, high_threshold=75, protected_networks=None, block_ttl_seconds=300):
        self.medium_threshold = medium_threshold
        self.high_threshold = high_threshold
        self.block_ttl_seconds = max(30, min(int(block_ttl_seconds), 3600))
        self.protected_networks = [ip_network(n) for n in (protected_networks or ["127.0.0.0/8", "::1/128"])]

    def is_protected(self, address: str | None) -> bool:
        if not address: return True
        ip = ip_address(address)
        return any(ip.version == n.version and ip in n for n in self.protected_networks)

    def decide(self, finding: DetectionFinding, source_ip: str | None = None) -> ResponseDecision:
        if source_ip and self.is_protected(source_ip):
            return ResponseDecision(finding_id=finding.finding_id, decision="blocked_by_policy", reason="Source belongs to a protected network; containment prohibited.", executed=False)
        if finding.risk_score >= self.high_threshold and finding.recommended_action == "containment_candidate":
            return ResponseDecision(finding_id=finding.finding_id, decision="would_block", reason="High-risk finding meets candidate threshold; Alpha 1 remains dry-run and executes no firewall changes.", executed=False, ttl_seconds=self.block_ttl_seconds)
        if finding.risk_score >= self.medium_threshold:
            return ResponseDecision(finding_id=finding.finding_id, decision="alert", reason="Finding meets investigation threshold; analyst review required.", executed=False)
        return ResponseDecision(finding_id=finding.finding_id, decision="record", reason="Below alert threshold; recorded for visibility and tuning.", executed=False)
