from .models import NetworkEvent
from .storage import Store
from .detection import DetectionEngine
from .policy import PolicyEngine

class NGFService:
    def __init__(self, db_path="./data/ngf.db"):
        self.store = Store(db_path)
        self.detector = DetectionEngine()
        self.policy = PolicyEngine()

    def process(self, event: NetworkEvent):
        if not event.event_id:
            # Stable enough for replay prevention within this event payload.
            import hashlib
            event.event_id = hashlib.sha256(event.model_dump_json().encode()).hexdigest()[:24]
        self.store.save_event(event)
        finding = self.detector.analyze(event)
        self.store.save_finding(finding)
        decision = self.policy.decide(finding, event.source_ip)
        self.store.save_decision(decision)
        return {"event": event.model_dump(mode="json"), "finding": finding.model_dump(mode="json"), "decision": decision.model_dump(mode="json")}
