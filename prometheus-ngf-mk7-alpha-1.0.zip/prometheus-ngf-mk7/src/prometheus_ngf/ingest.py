import json
from pathlib import Path
from typing import Iterator
from datetime import datetime, timezone
from .models import NetworkEvent

def parse_eve_record(row: dict) -> NetworkEvent | None:
    etype = row.get("event_type", "network_event")
    if etype not in {"alert", "flow", "dns", "http", "tls", "anomaly", "stats"}: return None
    alert = row.get("alert") or {}
    flow = row.get("flow") or {}
    # EVE event_id is generally not unique per record; derive a stable ID from content instead.
    raw = json.dumps(row, sort_keys=True, separators=(",", ":"))
    import hashlib
    event_id = hashlib.sha256(raw.encode()).hexdigest()[:24]
    timestamp = row.get("timestamp") or datetime.now(timezone.utc)
    return NetworkEvent(
        event_id=event_id, timestamp=timestamp, source_ip=row.get("src_ip"), source_port=row.get("src_port"),
        destination_ip=row.get("dest_ip"), destination_port=row.get("dest_port"),
        protocol=row.get("proto") or row.get("app_proto") or "UNKNOWN", sensor="suricata", event_type=etype,
        severity=str(alert.get("severity", "")) or None, signature=alert.get("signature"),
        bytes_in=int(flow.get("bytes_toserver", 0) or 0), bytes_out=int(flow.get("bytes_toclient", 0) or 0),
        duration_seconds=float(flow.get("age", 0) or 0),
        metadata={"eve_event_type": etype, "category": alert.get("category"), "signature_id": alert.get("signature_id")}
    )

def read_eve(path: str) -> Iterator[NetworkEvent]:
    p = Path(path)
    with p.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            if not line.strip(): continue
            try:
                row = json.loads(line)
                if not isinstance(row, dict): raise ValueError("record must be a JSON object")
                event = parse_eve_record(row)
                if event is not None: yield event
            except Exception as exc:
                print(f"WARN: skipped EVE line {line_no}: {exc}")
