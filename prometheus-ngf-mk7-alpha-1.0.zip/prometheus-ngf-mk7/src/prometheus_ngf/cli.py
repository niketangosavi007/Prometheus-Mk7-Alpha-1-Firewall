import argparse, json, os, sys
from .models import NetworkEvent
from .service import NGFService
from .ingest import read_eve

def main():
    parser = argparse.ArgumentParser(prog="ngf", description="Prometheus NGF Mk7 Alpha 1.0")
    sub = parser.add_subparsers(dest="cmd", required=True)
    nft = sub.add_parser("check-nftables", help="syntax-check an nftables file without applying it")
    nft.add_argument("path", nargs="?", default="config/ngf-nftables.example.nft")
    demo = sub.add_parser("demo", help="process safe synthetic events")
    demo.add_argument("--db", default=os.getenv("NGF_DB_PATH", "./data/ngf.db"))
    ingest = sub.add_parser("ingest-eve", help="ingest a Suricata EVE JSON file")
    ingest.add_argument("path", nargs="?", default=os.getenv("NGF_EVE_PATH", "./data/eve.json"))
    ingest.add_argument("--db", default=os.getenv("NGF_DB_PATH", "./data/ngf.db"))
    serve = sub.add_parser("serve", help="run local API")
    serve.add_argument("--host", default=os.getenv("NGF_HOST", "127.0.0.1"))
    serve.add_argument("--port", type=int, default=int(os.getenv("NGF_PORT", "8787")))
    args = parser.parse_args()
    if args.cmd == "check-nftables":
        import shutil, subprocess
        nft_bin = shutil.which("nft")
        if not nft_bin:
            print("nft command not found; install nftables first", file=sys.stderr); raise SystemExit(2)
        result = subprocess.run([nft_bin, "-c", "-f", args.path], text=True, capture_output=True, check=False)
        if result.stdout: print(result.stdout, end="")
        if result.stderr: print(result.stderr, end="", file=sys.stderr)
        if result.returncode == 0: print("Syntax check passed. No rules were applied.")
        raise SystemExit(result.returncode)
    if args.cmd == "serve":
        import uvicorn
        uvicorn.run("prometheus_ngf.api:app", host=args.host, port=args.port, reload=False)
        return
    service = NGFService(args.db)
    if args.cmd == "demo":
        events = [
            NetworkEvent(event_id="demo-normal-001", source_ip="192.0.2.10", destination_ip="198.51.100.20", destination_port=443, protocol="TCP", sensor="demo", event_type="flow"),
            NetworkEvent(event_id="demo-alert-001", source_ip="192.0.2.25", destination_ip="198.51.100.40", destination_port=22, protocol="TCP", sensor="demo", event_type="alert", severity="high", signature="ET SCAN Suspicious inbound connection"),
        ]
        for e in events: print(json.dumps(service.process(e), indent=2))
        print("\nDemo complete. All response decisions are dry-run; no firewall rules changed.")
    elif args.cmd == "ingest-eve":
        count = 0
        for event in read_eve(args.path):
            result = service.process(event); count += 1
            print(json.dumps({"event_id": result["event"]["event_id"], "risk_score": result["finding"]["risk_score"], "decision": result["decision"]["decision"]}))
        print(f"Processed {count} events. No firewall rules changed.")

if __name__ == "__main__": main()
