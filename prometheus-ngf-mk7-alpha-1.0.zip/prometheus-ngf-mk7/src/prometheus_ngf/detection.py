from collections import defaultdict, deque
from datetime import datetime, timezone
from hashlib import sha256
from .models import NetworkEvent, DetectionFinding

class DetectionEngine:
    """Explainable baseline detector. Heuristics are not a substitute for validated ML."""
    VERSION = "rules-baseline-v1"
    def __init__(self, unique_port_threshold=12, burst_threshold=80):
        self.unique_port_threshold = unique_port_threshold
        self.burst_threshold = burst_threshold
        self.source_ports = defaultdict(lambda: deque(maxlen=1000))
        self.source_events = defaultdict(lambda: deque(maxlen=1000))

    def analyze(self, event: NetworkEvent) -> DetectionFinding:
        now = event.timestamp.timestamp()
        src = event.source_ip or "unknown"
        if event.destination_port is not None:
            self.source_ports[src].append((now, event.destination_port))
        self.source_events[src].append(now)
        ports = {p for t, p in self.source_ports[src] if now - t <= 60}
        recent = sum(1 for t in self.source_events[src] if now - t <= 60)
        evidence, score = [], 0
        sig = (event.signature or "").lower()
        sev = (event.severity or "").lower()
        if "critical" in sev or "critical" in sig:
            score += 65; evidence.append("high_severity_sensor_alert")
        elif "high" in sev or "malware" in sig or "exploit" in sig:
            score += 45; evidence.append("elevated_sensor_alert")
        if len(ports) >= self.unique_port_threshold:
            score += 35; evidence.append(f"source_contacted_{len(ports)}_distinct_ports_in_60s")
        if recent >= self.burst_threshold:
            score += 30; evidence.append(f"source_generated_{recent}_events_in_60s")
        if event.event_type.lower() in {"alert", "anomaly", "dns_tunnel", "malware"}:
            score += 15; evidence.append(f"sensor_event_type_{event.event_type.lower()}")
        score = min(score, 100)
        if score >= 75: severity, action = "high", "containment_candidate"
        elif score >= 45: severity, action = "medium", "investigate"
        elif score >= 20: severity, action = "low", "investigate"
        else: severity, action = "info", "observe"
        event_id = event.event_id or sha256(event.model_dump_json().encode()).hexdigest()[:16]
        finding_id = sha256(f"{event_id}:{self.VERSION}:{score}".encode()).hexdigest()[:20]
        return DetectionFinding(finding_id=finding_id, event_id=event_id, timestamp=datetime.now(timezone.utc), risk_score=score, severity=severity, evidence=evidence or ["no_high_risk_heuristic_triggered"], recommended_action=action, model_version=self.VERSION)
