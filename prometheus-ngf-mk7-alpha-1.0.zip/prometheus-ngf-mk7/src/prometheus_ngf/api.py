"""Local management API. Sensitive endpoints fail closed without a configured token."""
import os, hmac
from fastapi import FastAPI, Header, HTTPException, Query
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from starlette.responses import Response
from .models import NetworkEvent
from .service import NGFService

DB_PATH = os.getenv("NGF_DB_PATH", "./data/ngf.db")
API_TOKEN = os.getenv("NGF_API_TOKEN", "")
app = FastAPI(title="Prometheus NGF Mk7", version="1.0.0-alpha.1", docs_url=None, redoc_url=None, description="Alpha 1 hardened detection and dry-run response core")
service = NGFService(DB_PATH)
EVENTS = Counter("ngf_events_processed_total", "Events processed")
REQUEST_LATENCY = Histogram("ngf_process_seconds", "Event processing duration")

def auth(authorization: str | None):
    if not API_TOKEN:
        raise HTTPException(status_code=503, detail="API disabled: set NGF_API_TOKEN before using protected endpoints")
    if not hmac.compare_digest(authorization or "", f"Bearer {API_TOKEN}"):
        raise HTTPException(status_code=401, detail="Missing or invalid bearer token")

@app.get("/health")
def health():
    return {"status": "ok", "project": "Prometheus NGF Mk7", "version": "1.0.0-alpha.1", "response_mode": "dry-run", "enforcement_enabled": False}

@app.post("/v1/events")
def ingest_event(event: NetworkEvent, authorization: str | None = Header(default=None)):
    auth(authorization)
    with REQUEST_LATENCY.time(): result = service.process(event)
    EVENTS.inc()
    return result

@app.get("/v1/findings")
def findings(limit: int = Query(default=50, ge=1, le=500), authorization: str | None = Header(default=None)):
    auth(authorization)
    items = service.store.list_findings(limit)
    return {"items": items, "count": len(items)}

@app.get("/v1/stats")
def stats(authorization: str | None = Header(default=None)):
    auth(authorization)
    return {**service.store.stats(), "response_mode": "dry-run"}

@app.get("/metrics")
def metrics(authorization: str | None = Header(default=None)):
    auth(authorization)
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
