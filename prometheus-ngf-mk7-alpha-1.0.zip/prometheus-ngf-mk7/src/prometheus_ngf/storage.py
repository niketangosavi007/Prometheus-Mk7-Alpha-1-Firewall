import json, sqlite3
from pathlib import Path
from typing import Any
from .models import NetworkEvent, DetectionFinding, ResponseDecision

class Store:
    def __init__(self, path: str = "./data/ngf.db"):
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._init()

    def _connect(self):
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init(self):
        with self._connect() as c:
            c.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS events(event_id TEXT PRIMARY KEY, timestamp TEXT NOT NULL, payload TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS findings(finding_id TEXT PRIMARY KEY, event_id TEXT NOT NULL, timestamp TEXT NOT NULL, payload TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS decisions(id INTEGER PRIMARY KEY AUTOINCREMENT, finding_id TEXT NOT NULL, timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, payload TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, action TEXT NOT NULL, detail TEXT NOT NULL);
            """)

    def save_event(self, event: NetworkEvent):
        payload = event.model_dump_json()
        with self._connect() as c:
            c.execute("INSERT OR IGNORE INTO events(event_id,timestamp,payload) VALUES(?,?,?)", (event.event_id, event.timestamp.isoformat(), payload))

    def save_finding(self, finding: DetectionFinding):
        with self._connect() as c:
            c.execute("INSERT OR REPLACE INTO findings(finding_id,event_id,timestamp,payload) VALUES(?,?,?,?)", (finding.finding_id, finding.event_id, finding.timestamp.isoformat(), finding.model_dump_json()))

    def save_decision(self, decision: ResponseDecision):
        with self._connect() as c:
            c.execute("INSERT INTO decisions(finding_id,payload) VALUES(?,?)", (decision.finding_id, decision.model_dump_json()))
            c.execute("INSERT INTO audit(action,detail) VALUES(?,?)", ("response_decision", decision.model_dump_json()))

    def audit(self, action: str, detail: dict[str, Any]):
        with self._connect() as c:
            c.execute("INSERT INTO audit(action,detail) VALUES(?,?)", (action, json.dumps(detail, sort_keys=True)))

    def list_findings(self, limit: int = 100):
        with self._connect() as c:
            rows = c.execute("SELECT payload FROM findings ORDER BY timestamp DESC LIMIT ?", (min(max(limit, 1), 500),)).fetchall()
        return [json.loads(r["payload"]) for r in rows]

    def stats(self):
        with self._connect() as c:
            events = c.execute("SELECT COUNT(*) n FROM events").fetchone()["n"]
            findings = c.execute("SELECT COUNT(*) n FROM findings").fetchone()["n"]
            decisions = c.execute("SELECT COUNT(*) n FROM decisions").fetchone()["n"]
        return {"events": events, "findings": findings, "decisions": decisions}
