from datetime import datetime, timezone
from ipaddress import ip_address
from typing import Any, Literal
from pydantic import BaseModel, Field, field_validator

class NetworkEvent(BaseModel):
    event_id: str | None = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    source_ip: str | None = None
    source_port: int | None = Field(default=None, ge=0, le=65535)
    destination_ip: str | None = None
    destination_port: int | None = Field(default=None, ge=0, le=65535)
    protocol: str = "UNKNOWN"
    sensor: str = "manual"
    event_type: str = "network_event"
    severity: str | None = None
    signature: str | None = None
    bytes_in: int = Field(default=0, ge=0)
    bytes_out: int = Field(default=0, ge=0)
    duration_seconds: float = Field(default=0.0, ge=0)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("source_ip", "destination_ip")
    @classmethod
    def validate_ip(cls, value):
        if value is not None:
            ip_address(value)
        return value

    @field_validator("protocol")
    @classmethod
    def normalize_protocol(cls, value):
        return value.upper().strip() or "UNKNOWN"

class DetectionFinding(BaseModel):
    finding_id: str
    event_id: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    risk_score: int = Field(ge=0, le=100)
    severity: Literal["info", "low", "medium", "high", "critical"]
    evidence: list[str] = Field(default_factory=list)
    recommended_action: Literal["observe", "investigate", "containment_candidate"] = "observe"
    model_version: str = "rules-baseline-v1"

class ResponseDecision(BaseModel):
    finding_id: str
    decision: Literal["record", "alert", "would_block", "blocked_by_policy"]
    reason: str
    executed: bool = False
    ttl_seconds: int | None = None
